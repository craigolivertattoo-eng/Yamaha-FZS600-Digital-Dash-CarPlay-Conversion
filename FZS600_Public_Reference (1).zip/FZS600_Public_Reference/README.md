# Craig's Yamaha FZS600 Fazer digital dash and CarPlay GPS conversion

Community build reference for a **1998 Yamaha FZS600 (5DM)** and an aftermarket **7-MS115** dash. Later model-year compatibility is **not established**.

> **Important:** These illustrations are build concepts and historical wiring notes, **not a fully verified wiring diagram**. Some images say 'VERIFIED' where no complete live functional test has been documented. Do not solder from image labels alone. Check against your bike's factory service manual, the exact dash seller's pinout, and multimeter readings.

## Image index

- [Dash wiring infographic](images/01-dash-wiring-reference.png) — contains inaccurate/overstated verification labels; see corrections below.
- [Dash mounting concept](images/02-dash-mount.png) — all hole sizes, bolt/thread sizes, and clearances require measurement.
- [Alternate duplicate dash mount illustration](images/03-dash-mount-duplicate.png).
- [Thundercat wheel-drive / speedometer cable concept](images/04-speedo-conversion-concept.png) — mechanical-to-electronic dash interface **not verified**.
- [CarPlay supply wiring concept](images/05-carplay-power-reference.png) — direct clock-loom feed requires circuit capacity and current verification.
- [Fuel sender and gauge test](images/06-fuel-sender-reference.png) — Green sender signal to Yellow/White dash input functionally tested by owner.

## Wiring reference and status

| 7-MS115 wire | FZS600 wire | Function | Status |
|---|---|---|---|
| Black | Brown | Ignition-switched supply | Owner previously reported confirmed; recheck with meter |
| Green | Black | Ground | Owner previously reported confirmed; recheck continuity |
| Red | Separately fused +12 V | Clock memory | Owner previously reported confirmed; fuse to suit verified dash requirements |
| Orange | Chocolate | Left turn | Proposed: test |
| Light Blue | Dark Green | Right turn | Proposed: test |
| Blue | Yellow | High beam | Proposed: test |
| Yellow/White | Green | Fuel sender | **Functionally tested:** gauge bars rise when float raised |
| Green/Red | Light Blue / Sky Blue (Sb) | Neutral | Proposed: test ground-switched behaviour; do NOT connect to FZS600 Green/Red |
| Brown | Black/Blue (B/L) | Low beam | Dash-side function confirmed by owner; bike-side wire still requires test |
| Yellow/Black | Undetermined | Tachometer | **Unverified — do not splice** |
| Speed input | Undetermined | Speedometer | **Unverified — do not splice** |

**Critical corrections to infographic:** The FZS600 Green/Red wire is the original low-fuel warning circuit, not neutral. The FZS600 neutral is Sky Blue/Light Blue. The 1998 FZS600 has an electronic speed sensor in the factory system; do not treat the original speedometer as exclusively mechanical. The infographic's claim that the dash speed input is unused is **not verified**. Its Brown dash low-beam row should point to candidate FZS600 Black/Blue, not plain Blue. No electrical or mechanical interface has been confirmed between the illustrated 940 mm Thundercat mechanical speedometer cable and the electronic 7-MS115 dash.

## Fuel sender owner test

The owner tested the sender outside the tank and reported that raising the float stopped the 7-MS115's flashing fuel indication and increased the displayed bars. This establishes functional response for the Green sender signal to Yellow/White dash fuel input. Approximate resistance values in the illustration should be independently checked against the exact sender specification before being treated as calibrated limits.

## CarPlay supply

The illustrated direct connection from switched Brown clock supply to CarPlay must **not** be copied unless spare circuit capacity and device current draw are established. Prefer an appropriately fused independent supply, ignition-triggered relay, and sound return ground when the clock circuit cannot support the load. Size the fuse to the device and wiring; '2 A' in the image is not a universal specification.

## Installation safety

Disconnect the battery before permanent splices; verify every circuit and connector; keep electrical testing away from open fuel tanks or petrol vapours; use proper strain relief, insulated joints, abrasion protection and weather sealing. Confirm speed readout accuracy before road use.

## Publication status

Reference package prepared for public release; wiring remains partly provisional. Contributions with measured pinouts, photographs of the actual dash wiring instructions, and road-tested speed-sensor details are welcome.
